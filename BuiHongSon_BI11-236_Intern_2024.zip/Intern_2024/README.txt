Backend: Flask Python
Database: MySQL Python in xampp (port: 3307)

Python library required:
1. flask
2. mysql.connector
3. datetime
4. bcrypt
5. calendar
6. io